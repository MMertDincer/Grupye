<?php require_once 'header.php'; ?>

<div class="container-fluid mt-2" style="background: white">
	<div class="row">
		<div class="col-xl-12">
			<h1 class="pt-3 pb-3" style="font-weight: bolder;">Hakkımızda</h1>
			<?php if($hakkimizdacek['hakkimizda_video_durum'] == 1){ ?>
				<div>
					<h3>Tanıtım Videosu</h3>
					<iframe src="https://www.youtube.com/embed/<?php echo $hakkimizdacek['hakkimizda_video']; ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
				</div>
			<?php } ?>
			<?php if($hakkimizdacek['hakkimizda_vizyon_durum'] == 1){ ?>
				<div>
					<h3>Vizyon</h3>
					<blockquote><?php echo $hakkimizdacek['hakkimizda_vizyon']; ?></blockquote>
				</div>
			<?php } ?>
			<?php if($hakkimizdacek['hakkimizda_misyon_durum'] == 1){ ?>
				<div>
					<h3>Misyon</h3>
					<blockquote><?php echo $hakkimizdacek['hakkimizda_misyon']; ?></blockquote>
				</div>
			<?php } ?>
			<?php if($hakkimizdacek['hakkimizda_icerik_durum'] == 1){ ?>				
				<div>
					<h3><?php echo $hakkimizdacek['hakkimizda_baslik']; ?></h3>
					<p><?php echo $hakkimizdacek['hakkimizda_icerik']; ?></p>
				</div>
			<?php } ?>
		</div>
	</div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>


<?php require_once 'footer.php'; ?>