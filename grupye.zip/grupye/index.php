<?php require_once 'header.php'; ?>

<div class="container ana">
	<div class="row">
		<div class="col-xl-12">
			<h1 class="display-1 text-center"><?php echo $ayarcek['ayar_mainpage_title']; ?></h1>
			<h4 class="text-center"><?php echo $ayarcek['ayar_mainpage_desc']; ?></h4>
		</div>
		<div class="col-xl-12 mt-5 search_bar_container">
			<input align="center" class="search_bar" type="text" name="" placeholder="Yemek, Mutfak, Bölge,">
			<button target="ara">Ara!</button>
		</div>
	</div>
</div>



<?php require_once 'footer.php'; ?>