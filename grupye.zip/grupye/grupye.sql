-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 23 Ara 2018, 18:23:36
-- Sunucu sürümü: 5.7.21
-- PHP Sürümü: 7.0.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `grupye`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayarlar`
--

DROP TABLE IF EXISTS `ayarlar`;
CREATE TABLE IF NOT EXISTS `ayarlar` (
  `ayar_id` int(11) NOT NULL,
  `ayar_logo` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `ayar_title` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `ayar_desc` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `ayar_keywords` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `ayar_author` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `ayar_mainpage_title` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `ayar_mainpage_desc` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `ayar_durum` enum('0','1') COLLATE utf8_turkish_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`ayar_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `ayarlar`
--

INSERT INTO `ayarlar` (`ayar_id`, `ayar_logo`, `ayar_title`, `ayar_desc`, `ayar_keywords`, `ayar_author`, `ayar_mainpage_title`, `ayar_mainpage_desc`, `ayar_durum`) VALUES
(0, 'images/22738food.jpg', 'Grupye', 'Grupye', 'yemek,yemek,yemek', 'Vols', 'Grupye Yusuf', '', '1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hakkimizda`
--

DROP TABLE IF EXISTS `hakkimizda`;
CREATE TABLE IF NOT EXISTS `hakkimizda` (
  `hakkimizda_id` int(11) NOT NULL,
  `hakkimizda_baslik` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `hakkimizda_baslik_durum` enum('0','1') COLLATE utf8_turkish_ci NOT NULL DEFAULT '1',
  `hakkimizda_icerik` text COLLATE utf8_turkish_ci NOT NULL,
  `hakkimizda_icerik_durum` enum('0','1') COLLATE utf8_turkish_ci NOT NULL DEFAULT '1',
  `hakkimizda_video` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `hakkimizda_video_durum` enum('0','1') COLLATE utf8_turkish_ci NOT NULL DEFAULT '1',
  `hakkimizda_vizyon` varchar(500) COLLATE utf8_turkish_ci NOT NULL,
  `hakkimizda_vizyon_durum` enum('0','1') COLLATE utf8_turkish_ci NOT NULL DEFAULT '1',
  `hakkimizda_misyon` varchar(500) COLLATE utf8_turkish_ci NOT NULL,
  `hakkimizda_misyon_durum` enum('0','1') COLLATE utf8_turkish_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`hakkimizda_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `hakkimizda`
--

INSERT INTO `hakkimizda` (`hakkimizda_id`, `hakkimizda_baslik`, `hakkimizda_baslik_durum`, `hakkimizda_icerik`, `hakkimizda_icerik_durum`, `hakkimizda_video`, `hakkimizda_video_durum`, `hakkimizda_vizyon`, `hakkimizda_vizyon_durum`, `hakkimizda_misyon`, `hakkimizda_misyon_durum`) VALUES
(0, 'Grupye Toplu Yemek Servisi', '1', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec iaculis felis ac mi malesuada porttitor. Fusce suscipit suscipit augue eu tristique. Vestibulum sit amet tempor ipsum, id convallis ex. Nulla commodo ultricies blandit. Praesent tincidunt odio vitae nisl ultrices, a viverra nunc bibendum. Mauris nec accumsan sem. Proin massa massa, consequat nec tristique id, dictum sed lectus. Curabitur maximus sed neque et congue. Maecenas enim ex, maximus eu neque ac, ornare fringilla sapien. Nullam eget mauris quis augue scelerisque feugiat a nec arcu. Aliquam et tincidunt lorem, nec hendrerit urna. Phasellus imperdiet nulla ex, hendrerit semper libero consectetur vel. Morbi velit nisi, venenatis in commodo in, iaculis vitae turpis. Fusce aliquet ultricies magna nec semper. Cras dictum felis dolor, efficitur pellentesque lorem molestie ac.</p>\r\n\r\n<p>Etiam pretium, velit at aliquam laoreet, eros mi laoreet lorem, eu egestas nisi erat et lorem. Sed accumsan quis dui a hendrerit. Phasellus ac egestas urna. Aliquam erat volutpat. Nam ut nulla sagittis, eleifend dui id, iaculis augue. Phasellus sed lacinia nulla. Suspendisse ornare erat ut orci viverra, sodales imperdiet est accumsan. Quisque condimentum dignissim tortor a vestibulum. Nulla non ex odio. Praesent id diam lobortis, pretium mauris et, elementum erat. Pellentesque eu mollis lectus, imperdiet fermentum quam. Vivamus rutrum turpis nibh, et luctus justo luctus vitae. Mauris porttitor tempor ex facilisis porttitor. Phasellus vitae elit blandit erat blandit porta ut eu orci.</p>\r\n\r\n<p>Proin dolor libero, pellentesque eu erat sit amet, pharetra blandit neque. Sed bibendum cursus turpis id vehicula. Suspendisse eu est rhoncus, tempor orci at, tempus purus. In pulvinar iaculis nulla sed elementum. Morbi ac iaculis nisl. Nunc pretium venenatis erat in consequat. Etiam ornare lectus eu accumsan condimentum. Phasellus tempor pharetra purus, non molestie felis condimentum id. Aenean vitae ipsum elit.</p>\r\n\r\n<p>Nam auctor interdum sapien, a faucibus nisl. Ut in nisi massa. Fusce fringilla a erat at convallis. Sed ut accumsan tortor. Curabitur pretium nibh quis viverra euismod. Duis at massa at tellus porta congue eu in orci. Ut luctus, augue sed blandit facilisis, nulla tortor rhoncus lorem, eget mattis ipsum ante et dolor. In vel erat condimentum, pharetra tortor vitae, tristique augue. Nulla efficitur, lectus pretium convallis volutpat, risus est aliquet dolor, vel posuere neque felis sed justo. Nunc convallis dui eget orci volutpat, eget condimentum turpis malesuada. Etiam in purus at odio facilisis porta nec et libero.</p>\r\n\r\n<p>Vivamus ante lectus, vehicula a justo lobortis, euismod fermentum nunc. Mauris non metus id mi placerat lobortis at vehicula mauris. Fusce ipsum orci, venenatis sit amet convallis aliquam, faucibus a ipsum. Integer in velit varius, suscipit mi id, tempus nunc. Pellentesque pretium hendrerit augue. Maecenas volutpat mi odio. Nam cursus a magna vel convallis. Sed nec diam in tortor sollicitudin gravida sed ac nibh. Nullam gravida nulla nec nunc venenatis bibendum. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nulla ut leo imperdiet, congue massa vel, malesuada ipsum.</p>\r\n', '1', '0J2QdDbelmY', '0', 'Grupye ile ilgili vizyon içeriği', '0', 'Grupye ile ilgili misyon içeriği', '0');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanici`
--

DROP TABLE IF EXISTS `kullanici`;
CREATE TABLE IF NOT EXISTS `kullanici` (
  `kullanici_id` int(11) NOT NULL AUTO_INCREMENT,
  `kullanici_ad` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `kullanici_soyad` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `kullanici_email` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `kullanici_sifre` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `kullanici_aktivasyon` enum('0','1') COLLATE utf8_turkish_ci NOT NULL DEFAULT '0',
  `kullanici_rutbe` varchar(50) COLLATE utf8_turkish_ci NOT NULL DEFAULT 'uye',
  `kullanici_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`kullanici_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kullanici`
--

INSERT INTO `kullanici` (`kullanici_id`, `kullanici_ad`, `kullanici_soyad`, `kullanici_email`, `kullanici_sifre`, `kullanici_aktivasyon`, `kullanici_rutbe`, `kullanici_date`) VALUES
(26, 'Yusuf', 'Güneş', 'yusufgunes@gmail.com', 'sifre', '1', 'master', '2018-11-03 22:34:53'),
(27, 'Armağan', 'Şentürk', 'menekse.3@hotmail.com', 'sifre', '1', 'uye', '2018-10-24 15:57:37');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_ust` varchar(50) COLLATE utf8_turkish_ci NOT NULL DEFAULT '0',
  `menu_ad` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `menu_detay` text COLLATE utf8_turkish_ci NOT NULL,
  `menu_url` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `menu_sira` int(2) NOT NULL,
  `menu_durum` enum('0','1') COLLATE utf8_turkish_ci NOT NULL,
  `menu_seourl` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `menu`
--

INSERT INTO `menu` (`menu_id`, `menu_ust`, `menu_ad`, `menu_detay`, `menu_url`, `menu_sira`, `menu_durum`, `menu_seourl`) VALUES
(1, '0', 'Hakkımızda', '<p>dsaaf</p>\r\n', '', 0, '1', 'hakkimizda'),
(28, '0', 'Yusuf Güneş', '<p>Yusuffnmdsfsdjfnsdfn&ouml;sdnfds&ouml;fnds&ouml;</p>\r\n', '', 4, '1', 'yusuf-gunes');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `slider`
--

DROP TABLE IF EXISTS `slider`;
CREATE TABLE IF NOT EXISTS `slider` (
  `slider_id` int(11) NOT NULL AUTO_INCREMENT,
  `slider_ad` varchar(150) COLLATE utf8_turkish_ci NOT NULL,
  `slider_resimyol` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `slider_sira` int(2) NOT NULL,
  `slider_link` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `slider_durum` enum('0','1') COLLATE utf8_turkish_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`slider_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
