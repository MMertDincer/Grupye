<?php 
require "admin/core/connect/connect.php";

$ayarsor=$db->prepare("SELECT * FROM ayarlar WHERE ayar_id=:id");
$ayarsor->execute(array(
  'id' => 0
));
$ayarcek=$ayarsor->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="utf-8">
<head>

  <title><?php echo $ayarcek['ayar_title'] ?></title>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="keywords" content="<?php echo $ayarcek['ayar_keywords'] ?>">
  <meta name="description" content="<?php echo $ayarcek['ayar_desc'] ?>">
  <meta name="author" content="<?php echo $ayarcek['ayar_author'] ?>">


  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles -->
  <link href="css/custom.css" rel="stylesheet">

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Font-->
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">

</head>

<body>

<nav class="navbar navbar-expand-lg bg-light ">
  <a class="navbar-brand ml-5" href="index.php"><img src="images/logo.png" width="50"></a>
  <button class="navbar-toggler btn btn-outline-primary" type="button" data-toggle="collapse" data-target="#anasayfa-nav" aria-controls="anasayfa-nav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="anasayfa-nav">
    <ul class="navbar-nav ml-auto mr-5">
      <li class="nav-item">
        <a class="nav-link" href="index.php">ANASAYFA<span class="sr-only">(current)</span></a>
      </li>
    </ul>
  </div>
</nav>

<div class="login-page">
	<div class="form rounded">
		<form class="login-form">
			<input type="email" placeholder="Email"/>
			<input type="password" placeholder="Şifre"/>
			<button>Giriş Yap</button>
			<p class="message">Şifrenizi mi unuttunuz? <a href="#">Yeni Şifre İste</a></p>
			<p class="message">Hesabınız yok mu? <a href="#">Hesap Oluştur</a></p>
		</form>
	</div>
</div>

</body>

</html>