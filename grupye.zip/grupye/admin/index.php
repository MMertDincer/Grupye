<?php require_once 'header.php' ?>
 <!--Admin Panel Main Page -->
<?php require_once 'footer.php' ?>