<?php 
include 'connect.php';

if(isset($_POST['login'])){
	echo "fmdsds";
}

if(isset($_POST['genset_save'])){
	$setsave = $db -> prepare("UPDATE settings SET
		settings_title=:settings_title,
		settings_desc=:settings_desc,
		settings_keywords=:settings_keywords,
		settings_author=:settings_author
		WHERE settings_id=0");

	$update = $setsave -> execute(array(
		'settings_title' => $_POST['settings_title'],
		'settings_desc' => $_POST['settings_desc'],
		'settings_keywords' => $_POST['settings_keywords'],
		'settings_author' => $_POST['settings_author']
	));

	if($update) {
		header("Location:../settings.php?durum=ok");
	} else {
		header("Location:../settings.php?durum=no");
	}
}

if(isset($_POST['mtxt_save'])){
	$setsave = $db -> prepare("UPDATE settings SET
		settings_mtxt=:settings_mtxt,
		settings_mdesc=:settings_mdesc
		WHERE settings_id=0");

	$update = $setsave -> execute(array(
		'settings_mtxt'=>$_POST['settings_mtxt'],
		'settings_mdesc'=>$_POST['settings_mdesc']
	));

	if($update) {
		header("Location:../settings.php?durum=ok");
	} else {
		header("Location:../settings.php?durum=no");
	}
}



 ?>