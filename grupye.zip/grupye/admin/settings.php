<?php require_once 'header.php'; ?>
<!--Admin Settings Page -->


<form action="core/process.php" method="POST" id="genset">
  <div class="col-md-12">
   <div class="card">
     <div class="card-header">
       Meta Tags
     </div>
     <div class="card-body">
       <label for="settings_mtxt">Title*</label>
       <input type="text" class="col-md-12" name="settings_title" value="<?php echo $settings_check['settings_title']; ?>">

       <label for="settings_mtxt">Description*</label>
       <input type="text" class="col-md-12" name="settings_desc" value="<?php echo $settings_check['settings_desc']; ?>">

       <label for="settings_mtxt">Keywords*</label>
       <input type="text" class="col-md-12" name="settings_keywords" value="<?php echo $settings_check['settings_keywords']; ?>">

       <label for="settings_mtxt">Author*</label>
       <input type="text" class="col-md-12" name="settings_author" value="<?php echo $settings_check['settings_author']; ?>">
     </div>
     <div class="card-footer">

      <?php 
      if($_GET['durum'] == "ok") { ?>
        <b style="color: green;">Success</b>
      <?php } elseif ($_GET['durum'] == "no") { ?>
        <b style="color: red;">Failed</b>
      <?php }  

      ?>

      <button class="btn btn-success" type="submit"  name="genset_save" style="float: right;">Update</button>
    </div>
  </div>
</div>
</form>

<!-- Setting -->
<form action="core/process.php" method="POST" id="genset2" style="padding: 10px 0 10px 0;">
  <div class="col-md-12">
   <div class="card">
     <div class="card-header">
       Carousel Caption
     </div>
     <div class="card-body">
       <label for="settings_mtxt">Header 1*</label>
       <input type="text" class="col-md-12" name="settings_mtxt" value="<?php echo $settings_check['settings_mtxt']; ?>">

       <label for="settings_mtxt">Description*</label>
       <input type="text" class="col-md-12" name="settings_mdesc" value="<?php echo $settings_check['settings_mdesc']; ?>">
     </div>
     <div class="card-footer">

      <?php 
      if($_GET['durum'] == "ok") { ?>
        <b style="color: green;">Success</b>
      <?php } elseif ($_GET['durum'] == "no") { ?>
        <b style="color: red;">Failed</b>
      <?php }  

      ?>

      <button class="btn btn-success" type="submit"  name="mtxt_save" style="float: right;">Update</button>
    </div>
  </div>
</div>
</form>


<!--Footer-->
<?php require_once 'footer.php' ?>