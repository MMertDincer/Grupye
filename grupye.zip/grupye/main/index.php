<?php require_once 'header.php'; ?>


<!--Slider + Reklam-->
<div class="container-fluid">
	<div class="row ana">
		<div class="col-xl-6 col-md-12">
			<div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
				<div class="carousel-inner">
					<div class="carousel-item active">
						<img class="d-block w-100" src="../images/food.jpg" alt="First slide">
					</div>
					<div class="carousel-item">
						<img class="d-block w-100" src="../images/food.jpg" alt="Second slide">
					</div>
					<div class="carousel-item">
						<img class="d-block w-100" src="../images/food.jpg" alt="Third slide">
					</div>
				</div>
				<a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
		</div>
		<div class="col-xl-6 col-md-12">
			<div class="container">
				<div class="row">
					<a class="container-fluid" style="text-decoration: none; color: black;" href="#">
						<div class="col-12 border ana2">
							<div class="row">
								<div class="col-4">
									<div class="container" style="margin-top: 12px;">
										<img src="../images/food.jpg" height="100">
									</div>
								</div>
								<div class="col-8">
									<div class="reklam_yazisi">
										<div class="reklam_baslik">Başlık</div>
										<p class="reklam_icerik">İçerik</p>
									</div>
								</div>					
							</div>
						</div>
					</a>
					<a class="container-fluid" style="text-decoration: none; color: black;" href="#">
						<div class="col-12 border ana2">
							<div class="row">
								<div class="col-4">
									<div class="container" style="margin-top: 12px;">
										<img src="../images/food.jpg" height="100">
									</div>
								</div>
								<div class="col-8">
									<div class="reklam_yazisi">
										<div class="reklam_baslik">Başlık</div>
										<p class="reklam_icerik">İçerik </p>
									</div>
								</div>					
							</div>
						</div>
					</a>
					<a class="container-fluid rek_hover" style="text-decoration: none; color: black;" href="#">
						<div class="col-12 border ana2">
							<div class="row">
								<div class="col-4">
									<div class="container" style="margin-top: 12px;">
										<img src="../images/food.jpg" height="100">
									</div>
								</div>
								<div class="col-8">
									<div class="reklam_yazisi">
										<div class="reklam_baslik">Başlık</div>
										<p class="reklam_icerik">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
											tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
											quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
											consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
											cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
										proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
									</div>
								</div>					
							</div>
						</div>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>

<!--Main Page-->
<div class="container-fluid">
	<div class="row ana">
		<div class="col-xl-4 col-12 main_liste">
			<a href="">
				<img src="../images/food.jpg" width="100%">	
			</a>
		</div>
		<div class="col-xl-4 col-12 main_liste">
			<a href="">
				<img src="../images/food.jpg" width="100%">
			</a>
		</div>
		<div class="col-xl-4 col-12 main_liste">
			<a href="">
				<img src="../images/food.jpg" width="100%">
			</a>
		</div>
	</div>
	<div class="row ana">
		<div class="col-xl-4 col-12 main_liste">
			<a href="">
				<img src="../images/food.jpg" width="100%">	
			</a>
		</div>
		<div class="col-xl-4 col-12 main_liste">
			<a href="">
				<img src="../images/food.jpg" width="100%">
			</a>
		</div>
		<div class="col-xl-4 col-12 main_liste">
			<a href="">
				<img src="../images/food.jpg" width="100%">
			</a>
		</div>
	</div>
	<div class="row ana">
		<div class="col-xl-4 col-12 main_liste">
			<a href="">
				<img src="../images/food.jpg" width="100%">	
			</a>
		</div>
		<div class="col-xl-4 col-12 main_liste">
			<a href="">
				<img src="../images/food.jpg" width="100%">
			</a>
		</div>
		<div class="col-xl-4 col-12 main_liste">
			<a href="">
				<img src="../images/food.jpg" width="100%">
			</a>
		</div>
	</div>
</div>



<?php require_once 'footer.php'; ?>