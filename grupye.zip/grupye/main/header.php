<?php 
require_once "../admin/core/connect/connect.php";
require_once "../admin/core/proc.php";
require_once "../admin/core/function.php";

$ayarsor=$db->prepare("SELECT * FROM ayarlar WHERE ayar_id=:id");
$ayarsor->execute(array(
  'id' => 0
));
$ayarcek=$ayarsor->fetch(PDO::FETCH_ASSOC);

$hakkimizdasor=$db->prepare("SELECT * FROM hakkimizda WHERE hakkimizda_id=:id");
$hakkimizdasor->execute(array(
  'id' => 0
));
$hakkimizdacek=$hakkimizdasor->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="utf-8">
<head>

  <title><?php echo $ayarcek['ayar_title'] ?></title>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="keywords" content="<?php echo $ayarcek['ayar_keywords'] ?>">
  <meta name="description" content="<?php echo $ayarcek['ayar_desc'] ?>">
  <meta name="author" content="<?php echo $ayarcek['ayar_author'] ?>">


  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles -->
  <link href="../css/main.css" rel="stylesheet">

  <!-- Bootstrap core JavaScript -->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Font-->
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">

</head>

<body>

<nav class="navbar navbar-expand-lg bg-light">
  <a class="navbar-brand ml-5" href="index.php"><img src="<?php echo "../".$ayarcek['ayar_logo']; ?>" width="50"></a>
    <ul class="navbar-nav ml-auto mr-2">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Anasayfa<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link rounded" target="giris" href="login.php">Giriş Yap</a>
      </li>
    </ul>
    <button class="navbar-light navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
</nav>
<nav class="navbar navbar-expand-lg bg-white">
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      
      <?php 
      $menusor=$db->prepare("SELECT * FROM menu WHERE menu_durum=:durum ORDER BY menu_sira ASC LIMIT 3");
      $menusor->execute(array(
        'durum' => 1
      ));

      while($menuyaz=$menusor->fetch(PDO::FETCH_ASSOC)){ ?>

      <li class="nav-item">
        <a class="nav-link" href="

        <?php if(!empty($menuyaz['menu_url'])){
          echo $menuyaz['menu_url'];
        }else{
          echo "page-".seo($menuyaz['menu_ad']);
        }?>

        "><?php echo $menuyaz['menu_ad']; ?></a>
      
      </li>

    <?php } ?>
      <li>
        <div class="col-xl-12">
          <input class="search_bar" type="text" name="" placeholder="Yemek, Mutfak, Bölge,">
          <button target="ara">Ara!</button>
        </div>
      </li>
    </ul>
  </div>
</nav>
