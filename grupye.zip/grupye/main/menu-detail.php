<?php require_once 'header.php';	 	

$menusor=$db->prepare("SELECT * FROM menu WHERE menu_seourl=:sef");
$menusor->execute(array(
	'sef' => $_GET['sef']
));
$menucek=$menusor->fetch(PDO::FETCH_ASSOC);	
?>

<div class="container-fluid mt-2" style="background: white">
	<div class="row">
		<div class="col-xl-12">
			<h1 class="pt-3" style="font-weight: bolder;"><?php echo $menucek['menu_ad']; ?></h1>
			<p class=""><?php echo $menucek['menu_detay']; ?></p>
		</div>
	</div>
</div>


<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>


<?php require_once 'footer.php'; ?>